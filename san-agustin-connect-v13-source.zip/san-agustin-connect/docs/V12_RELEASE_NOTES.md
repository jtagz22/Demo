# V12 Release Notes

- Android version 12.0.0 / versionCode 12
- Explicit preview APK profile
- Explicit production AAB profile
- Expo health-check script
- Deployment/security checklist
- Municipal-data validation checklist
- Emergency-response drill checklist
- Clear separation between source readiness and actual signed APK generation

## Important
The final binary still has to be produced by running the EAS Android build. The current ChatGPT environment does not have an authenticated Android signing/EAS build session, so no fake `.apk` is presented.
