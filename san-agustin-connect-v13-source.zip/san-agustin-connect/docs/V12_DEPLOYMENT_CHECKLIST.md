# V12 Deployment Checklist

## Before APK build
- [ ] Set `EXPO_PUBLIC_API_URL` to production HTTPS API.
- [ ] Run `npm install`.
- [ ] Run `npx expo-doctor`.
- [ ] Authenticate with EAS.
- [ ] Link the EAS project.
- [ ] Configure Android application signing.
- [ ] Confirm package `ph.gov.sanagustin.mdrrmo`.

## Backend
- [ ] Use PostgreSQL, not in-memory incident storage.
- [ ] Set a long random `JWT_SECRET`.
- [ ] Replace all demo credentials.
- [ ] Restrict CORS to official domains.
- [ ] Put API behind HTTPS.
- [ ] Configure backups.
- [ ] Configure server monitoring/logging.
- [ ] Configure push notification credentials.

## Municipal data
- [ ] Verify evacuation-center coordinates/capacity.
- [ ] Verify emergency phone numbers.
- [ ] Verify MDRRMO personnel/roles.
- [ ] Verify barangay coverage.
- [ ] Establish who can publish alerts.
- [ ] Establish incident escalation policy.

## Operational test
- [ ] Resident submits test incident.
- [ ] GPS permission works.
- [ ] Offline report queues.
- [ ] Report synchronizes after reconnection.
- [ ] Dispatcher sees incident.
- [ ] Responder changes status.
- [ ] Command center records audit event.
- [ ] Alert reaches test devices.
- [ ] Recovery/backup procedure tested.

## APK
Command:
`npx eas build --platform android --profile preview`

Expected result: an EAS-generated `.apk` download artifact.
