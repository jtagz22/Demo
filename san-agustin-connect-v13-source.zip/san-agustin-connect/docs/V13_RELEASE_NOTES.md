# V13 Release Notes — San Agustin Connect

- Rebranded app name and welcome screen to San Agustin Connect.
- Adopted headline: “BE INFORMED. BE PREPARED. EXPLORE SAN AGUSTIN.”
- Added Weather Updates, Announcements, and Tourist Spots navigation screens.
- Added preparedness reminders while clearly identifying that live weather is not yet connected.
- Avoided presenting unverified events, weather conditions, tourism listings, emergency contacts, or evacuation locations as official facts.
- Retained the existing MDRRMO emergency-response project routes and backend files.
- App version 13.0.0, Android versionCode 13; Android package remains ph.gov.sanagustin.mdrrmo.

## Not yet production-connected
Weather data, authorized live announcements, verified tourist listings, and municipal emergency directory data must be configured/validated. A signed APK must be produced using EAS Build with an authenticated account.
