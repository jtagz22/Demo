V11 is the operations/deployment release.

The APK source/build configuration is complete. A signed APK binary still requires execution of the EAS Android build with an authenticated project and signing configuration. No fake APK is supplied.
