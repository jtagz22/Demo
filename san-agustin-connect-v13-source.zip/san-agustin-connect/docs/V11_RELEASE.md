# V11 Release Notes

## Operational additions
- Browser command center dashboard
- Live incident polling
- Incident status progression
- Authenticated status changes
- Role-protected alert publishing
- Admin-only audit endpoint
- PostgreSQL schema for users/responders/incidents/events/alerts/evacuation/contact/audit data
- Resident offline emergency queue
- Android APK build profile

## Build APK
cd mobile
npm install
npx eas login
npx eas build:configure
npx eas build --platform android --profile preview

## Security gate
Before operational deployment:
- replace demo passwords
- generate a strong JWT secret
- use HTTPS
- connect the API to PostgreSQL
- configure real municipal data
- configure push notification credentials
- enable backups and monitoring
- perform a supervised emergency-response drill
