from fastapi import FastAPI,HTTPException,Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from datetime import datetime,timezone,timedelta
from jose import jwt
import os,uuid
app=FastAPI(title="MDRRMO San Agustin V11",version="11.0.0")
app.add_middleware(CORSMiddleware,allow_origins=os.getenv("CORS_ORIGINS","*").split(","),allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
SECRET=os.getenv("JWT_SECRET","change-me")
USERS={"admin":{"password":"change-me","role":"ADMIN"},"dispatcher":{"password":"change-me","role":"DISPATCHER"},"responder":{"password":"change-me","role":"RESPONDER"}}
INCIDENTS=[];ALERTS=[];AUDIT=[]
class Login(BaseModel):username:str;password:str
class Incident(BaseModel):type:str;details:str;latitude:float|None=None;longitude:float|None=None;priority:str="HIGH"
class Status(BaseModel):status:str
class Alert(BaseModel):title:str;message:str;severity:str="WARNING"
def auth(token):
    if not token or not token.startswith("Bearer "): raise HTTPException(401,"Authentication required")
    try:return jwt.decode(token[7:],SECRET,algorithms=["HS256"])
    except:raise HTTPException(401,"Invalid session")
@app.get("/health")
def health():return {"status":"ok","version":"11.0.0"}
@app.post("/api/v1/auth/login")
def login(x:Login):
    u=USERS.get(x.username)
    if not u or u["password"]!=x.password:raise HTTPException(401,"Invalid credentials")
    token=jwt.encode({"sub":x.username,"role":u["role"],"exp":datetime.now(timezone.utc)+timedelta(hours=8)},SECRET,algorithm="HS256")
    return {"access_token":token,"role":u["role"]}
@app.post("/api/v1/incidents")
def create(x:Incident):
    i={"id":str(uuid.uuid4()),"status":"RECEIVED","created_at":datetime.now(timezone.utc).isoformat(),"assigned_responder_id":None,**x.model_dump()};INCIDENTS.append(i);return i
@app.get("/api/v1/incidents")
def list_incidents(status:str|None=None):return [i for i in INCIDENTS[::-1] if not status or i["status"]==status]
@app.patch("/api/v1/incidents/{id}/status")
def status(id:str,x:Status,authorization:str|None=Header(default=None)):
    actor=auth(authorization);i=next((z for z in INCIDENTS if z["id"]==id),None)
    if not i:raise HTTPException(404,"Not found")
    i["status"]=x.status;AUDIT.append({"actor":actor["sub"],"action":"STATUS_CHANGE","incident_id":id,"status":x.status,"at":datetime.now(timezone.utc).isoformat()});return i
@app.post("/api/v1/alerts")
def create_alert(x:Alert,authorization:str|None=Header(default=None)):
    actor=auth(authorization)
    if actor["role"] not in ("ADMIN","DISPATCHER"):raise HTTPException(403,"Insufficient role")
    a={"id":str(uuid.uuid4()),"created_at":datetime.now(timezone.utc).isoformat(),**x.model_dump()};ALERTS.append(a);AUDIT.append({"actor":actor["sub"],"action":"ALERT_PUBLISHED","alert_id":a["id"]});return a
@app.get("/api/v1/alerts")
def alerts():return ALERTS[::-1]
@app.get("/api/v1/audit")
def audit(authorization:str|None=Header(default=None)):
    actor=auth(authorization)
    if actor["role"]!="ADMIN":raise HTTPException(403,"Admin only")
    return AUDIT[::-1]
@app.get("/api/v1/evacuation-centers")
def centers():return []
@app.get("/api/v1/emergency-contacts")
def contacts():return []
