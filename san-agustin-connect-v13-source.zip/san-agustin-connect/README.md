# San Agustin Connect — V13 App Source

**Headline:** BE INFORMED. BE PREPARED. EXPLORE SAN AGUSTIN.

An Expo / React Native Android application for MDRRMO San Agustin, Romblon, continuing the existing emergency-response project with a community-focused home screen and sections for weather, announcements, tourism, emergency reporting, alerts, evacuation centers, contacts, and responder workflows.

## What's new in V13
- Rebranded app name and home screen as **San Agustin Connect**.
- Welcome screen follows the approved navy, ivory, and gold theme.
- Added navigation tiles for Weather Updates, Announcements, Tourist Spots, and Emergency Info.
- Added Weather Updates screen with preparedness reminders and a clear notice that live weather integration is not configured.
- Added Announcements screen designed for authorized official notices; it does not fabricate current events.
- Added Tourist Spots screen with discovery categories. Specific local attraction listings need verification and entry by the municipal tourism office.
- Kept the existing emergency report, alerts, evacuation, emergency contacts, responder, login, backend, and database project files.
- Android app version 13.0.0; Android versionCode 13. Package ID remains `ph.gov.sanagustin.mdrrmo`.

## Run the mobile app locally
```bash
cd mobile
npm install
npx expo start
```

## Build an installable Android APK
You need Node.js/npm, an Expo account, and an authenticated EAS Build session:
```bash
cd mobile
npm install
npx expo-doctor
npx eas login
npx eas build:configure
npx eas build --platform android --profile preview
```
The EAS build will provide an APK download when the remote build completes. A signed APK is **not included** in this source ZIP because no authenticated Android build was run here.

## Production Android App Bundle
```bash
cd mobile
npx eas build --platform android --profile production
```

## Important deployment notes
- The weather screen currently does not display live weather; configure an approved weather data source before release.
- The announcements screen requires a connected, authorized feed/backend before it can show current municipal events and alerts.
- Tourism categories are starter content only. Verify and add actual destinations, images, directions, and visitor information with the local tourism office.
- Verify all emergency telephone numbers, evacuation center locations, and public-safety instructions before public launch.
- Configure `EXPO_PUBLIC_API_URL` to point to a deployed HTTPS backend; do not leave a production app using localhost.
- Test GPS permission, notification delivery, offline emergency report queuing, API authentication, and role permissions on real devices before deployment.
