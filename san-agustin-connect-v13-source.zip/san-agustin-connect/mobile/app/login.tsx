import {useState} from "react";
import {SafeAreaView,Text,TextInput,Button,Alert,StyleSheet} from "react-native";
import * as SecureStore from "expo-secure-store";
const API=process.env.EXPO_PUBLIC_API_URL||"http://localhost:8000";
export default function Login(){const[u,setU]=useState(""),[p,setP]=useState("");
async function login(){try{const r=await fetch(API+"/api/v1/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:u,password:p})});if(!r.ok)throw Error();const x=await r.json();await SecureStore.setItemAsync("mdrrmo_token",x.access_token);await SecureStore.setItemAsync("mdrrmo_role",x.role);Alert.alert("Login successful",`Role: ${x.role}`)}catch{Alert.alert("Login failed","Invalid credentials or server unavailable.")}}
return <SafeAreaView style={s.p}><Text style={s.h}>Secure Login</Text><TextInput style={s.i} placeholder="Username" value={u} onChangeText={setU} autoCapitalize="none"/><TextInput style={s.i} placeholder="Password" value={p} onChangeText={setP} secureTextEntry/><Button title="LOGIN" onPress={login}/></SafeAreaView>}
const s=StyleSheet.create({p:{flex:1,padding:20,gap:12},h:{fontSize:28,fontWeight:"900"},i:{borderWidth:1,borderColor:"#ccd7df",borderRadius:12,padding:12}});
