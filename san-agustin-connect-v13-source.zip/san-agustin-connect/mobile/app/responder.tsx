import {useEffect,useState} from "react";
import {SafeAreaView,Text,View,StyleSheet,Pressable} from "react-native";
const API=process.env.EXPO_PUBLIC_API_URL||"http://localhost:8000";
export default function Responder(){const[x,setX]=useState<any[]>([]);
async function load(){try{const r=await fetch(API+"/api/v1/incidents?status=ASSIGNED");setX(await r.json())}catch{}}
useEffect(()=>{load();const t=setInterval(load,10000);return()=>clearInterval(t)},[]);
return <SafeAreaView style={s.p}><Text style={s.h}>Responder Console</Text>{x.length===0?<Text style={s.t}>No assigned incidents.</Text>:x.map(i=><View key={i.id} style={s.card}><Text style={s.type}>{i.type}</Text><Text>{i.details}</Text><Text style={s.meta}>{i.priority} • {i.status}</Text><Pressable style={s.btn} onPress={async()=>{await fetch(API+"/api/v1/incidents/"+i.id+"/status",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({status:"EN_ROUTE"})});load()}}><Text style={s.bt}>MARK EN ROUTE</Text></Pressable></View>)}</SafeAreaView>}
const s=StyleSheet.create({p:{flex:1,padding:20},h:{fontSize:28,fontWeight:"900",marginBottom:14},t:{color:"#657985"},card:{padding:16,borderRadius:15,backgroundColor:"#fff",marginBottom:10,borderWidth:1,borderColor:"#e0e8ed"},type:{fontSize:18,fontWeight:"900"},meta:{marginTop:7,color:"#8a4d00"},btn:{marginTop:12,backgroundColor:"#17649a",padding:11,borderRadius:9},bt:{color:"#fff",fontWeight:"900",textAlign:"center"}});
