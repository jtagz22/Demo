import {SafeAreaView,Text,StyleSheet} from "react-native";
export default function Screen(){return <SafeAreaView style={s.p}><Text style={s.h}>Disaster Alerts</Text><Text style={s.t}>Official MDRRMO alerts will appear here and can be delivered through push notifications.</Text></SafeAreaView>}
const s=StyleSheet.create({p:{flex:1,padding:20},h:{fontSize:28,fontWeight:"900",marginBottom:14},t:{color:"#657985",lineHeight:22}});
